var jumpSort = function(tail) {
    // body...
    // console.log(this);
    var url = './searchlist.html?sortId='+tail;
    console.log(url);
    location.href = url;
};